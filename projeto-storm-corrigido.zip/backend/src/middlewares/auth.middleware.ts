import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import { AppError } from '../utils/app-error';
import { AuthRequest } from '../types/auth.types';

export const authMiddleware = async (req: Request, res: Response, next: NextFunction) => {
  try {
    // Get authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Unauthorized', 401);
    }
    
    // Extract token
    const token = authHeader.split(' ')[1];
    
    if (!token) {
      throw new AppError('Unauthorized', 401);
    }
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'jwt-secret') as { userId: string };
    
    // Get user from database
    const prisma = new PrismaClient();
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId }
    });
    
    if (!user) {
      throw new AppError('Unauthorized', 401);
    }
    
    // Add user to request
    (req as AuthRequest).user = {
      id: user.id,
      email: user.email,
      name: user.name,
      tenantId: user.tenantId || undefined
    };
    
    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      return next(new AppError('Unauthorized', 401));
    }
    return next(error);
  }
};