import jwt from 'jsonwebtoken';
import { PrismaClient } from '@prisma/client';
import { AppError } from '../utils/app-error';

export class TokenService {
  private prisma: PrismaClient;
  private jwtSecret: string;
  private jwtRefreshSecret: string;
  private jwtExpiresIn: string;
  private refreshTokenExpiresIn: string;

  constructor() {
    this.prisma = new PrismaClient();
    this.jwtSecret = process.env.JWT_SECRET || 'jwt-secret';
    this.jwtRefreshSecret = process.env.JWT_REFRESH_SECRET || 'jwt-refresh-secret';
    this.jwtExpiresIn = process.env.JWT_EXPIRES_IN || '15m';
    this.refreshTokenExpiresIn = process.env.REFRESH_TOKEN_EXPIRES_IN || '7d';
  }

  generateAccessToken(userId: string): string {
    return jwt.sign({ userId }, this.jwtSecret, {
      expiresIn: this.jwtExpiresIn
    });
  }

  async generateRefreshToken(userId: string, oldToken?: string): Promise<string> {
    // If old token exists, revoke it
    if (oldToken) {
      await this.revokeRefreshToken(oldToken);
    }

    // Generate new token
    const refreshToken = jwt.sign({ userId }, this.jwtRefreshSecret, {
      expiresIn: this.refreshTokenExpiresIn
    });

    // Calculate expiry date
    const expiresInMs = this.parseExpiresIn(this.refreshTokenExpiresIn);
    const expiresAt = new Date(Date.now() + expiresInMs);

    // Save token to database
    await this.prisma.refreshToken.create({
      data: {
        token: refreshToken,
        userId,
        expiresAt
      }
    });

    return refreshToken;
  }

  async verifyRefreshToken(token: string): Promise<{ userId: string }> {
    // Verify token signature
    const decoded = jwt.verify(token, this.jwtRefreshSecret) as { userId: string };

    // Check if token exists in database
    const refreshToken = await this.prisma.refreshToken.findUnique({
      where: { token }
    });

    if (!refreshToken) {
      throw new AppError('Invalid refresh token', 401);
    }

    // Check if token is expired
    if (refreshToken.expiresAt < new Date()) {
      await this.prisma.refreshToken.delete({
        where: { id: refreshToken.id }
      });
      throw new AppError('Refresh token expired', 401);
    }

    return { userId: decoded.userId };
  }

  async revokeRefreshToken(token: string): Promise<void> {
    try {
      await this.prisma.refreshToken.delete({
        where: { token }
      });
    } catch (error) {
      throw new AppError('Invalid refresh token', 401);
    }
  }

  private parseExpiresIn(expiresIn: string): number {
    const match = expiresIn.match(/^(\d+)([smhd])$/);
    
    if (!match) {
      return 7 * 24 * 60 * 60 * 1000; // Default to 7 days
    }
    
    const value = parseInt(match[1]);
    const unit = match[2];
    
    switch (unit) {
      case 's':
        return value * 1000; // seconds to milliseconds
      case 'm':
        return value * 60 * 1000; // minutes to milliseconds
      case 'h':
        return value * 60 * 60 * 1000; // hours to milliseconds
      case 'd':
        return value * 24 * 60 * 60 * 1000; // days to milliseconds
      default:
        return 7 * 24 * 60 * 60 * 1000; // Default to 7 days
    }
  }
}