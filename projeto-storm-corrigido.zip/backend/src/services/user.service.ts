import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
import { UpdateUserInput } from '../schemas/user.schema';
import { AppError } from '../utils/app-error';

export class UserService {
  private prisma: PrismaClient;

  constructor() {
    this.prisma = new PrismaClient();
  }

  async getById(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId }
    });

    if (!user) {
      throw new AppError('User not found', 404);
    }

    // Return user without password
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  }

  async update(userId: string, userData: UpdateUserInput) {
    // Get existing user
    const existingUser = await this.prisma.user.findUnique({
      where: { id: userId }
    });

    if (!existingUser) {
      throw new AppError('User not found', 404);
    }

    // Check if email is already in use
    if (userData.email && userData.email !== existingUser.email) {
      const userWithEmail = await this.prisma.user.findUnique({
        where: { email: userData.email }
      });

      if (userWithEmail) {
        throw new AppError('Email already in use', 409);
      }
    }

    // Prepare data for update
    const updateData: any = {};
    
    if (userData.name) {
      updateData.name = userData.name;
    }
    
    if (userData.email) {
      updateData.email = userData.email;
    }
    
    if (userData.password) {
      updateData.password = await bcrypt.hash(userData.password, 10);
    }

    // Update user
    const updatedUser = await this.prisma.user.update({
      where: { id: userId },
      data: updateData
    });

    // Return user without password
    const { password, ...userWithoutPassword } = updatedUser;
    return userWithoutPassword;
  }
}