import path from "path"
import react from "@vitejs/plugin-react"
import { defineConfig } from "vite"
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
  server: {
    allowedHosts: [
      "5174-ipbrhjfwdo7qm6r4anj8i-7b69be13.manusvm.computer",
      "localhost",
      "127.0.0.1",
      ".manusvm.computer"
    ],
  },
})

